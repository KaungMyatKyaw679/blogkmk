<div {{$attributes->merge(['class'=>"card p-3 mx-auto"])}}>
     {{$slot}}
</div>
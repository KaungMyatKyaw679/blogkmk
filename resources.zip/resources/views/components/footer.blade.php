<div class="bg-dark  text-white p-5">
      <footer class="py-3">
        <ul class="nav justify-content-center">
          <li class="nav-item">
            <a href="#home" class="nav-link px-2">Home</a>
          </li>
          <li class="nav-item">
            <a href="#blogs" class="nav-link px-2">Blogs</a>
          </li>
          <li class="nav-item">
            <a href="#subscribe" class="nav-link px-2">Subscribe us</a>
          </li>
        </ul>
        <p class="text-center">&copy; 2021 Blogs By taungchunmyae, Inc</p>
      </footer>
</div>
<x-layout>
<h1>Hello {{$user->name}} </h1>
<h3>title : {{$blog->title}}</h3>
</x-layout>